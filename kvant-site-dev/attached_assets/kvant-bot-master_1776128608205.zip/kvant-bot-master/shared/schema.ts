import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, serial, integer, boolean, timestamp, bigint, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  telegramId: bigint("telegram_id", { mode: "number" }).notNull().unique(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  age: integer("age"),
  grade: text("grade"),
  goal: text("goal"),
  phone: text("phone"),
  telegramUsername: text("telegram_username"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ many }) => ({
  bookings: many(bookings),
  subscriptions: many(subscriptions),
  accounts: many(accounts),
}));

export const groupSchedule = pgTable("group_schedule", {
  id: serial("id").primaryKey(),
  dayOfWeek: integer("day_of_week").notNull(),
  time: text("time").notNull(),
  title: text("title"),
  maxStudents: integer("max_students").default(10).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  slotType: text("slot_type").default("group").notNull(),
  specificDate: text("specific_date"),
});

export const groupScheduleRelations = relations(groupSchedule, ({ many }) => ({
  bookings: many(bookings),
}));

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(),
  date: text("booking_date").notNull(),
  time: text("time").notNull(),
  status: text("status").default("confirmed").notNull(),
  isPaid: boolean("is_paid").default(false).notNull(),
  groupScheduleId: integer("group_schedule_id").references(() => groupSchedule.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const bookingsRelations = relations(bookings, ({ one }) => ({
  user: one(users, { fields: [bookings.userId], references: [users.id] }),
  groupSlot: one(groupSchedule, { fields: [bookings.groupScheduleId], references: [groupSchedule.id] }),
}));

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(),
  totalLessons: integer("total_lessons").notNull(),
  remainingLessons: integer("remaining_lessons").notNull(),
  isPaid: boolean("is_paid").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  user: one(users, { fields: [subscriptions.userId], references: [users.id] }),
}));

export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  firstName: text("first_name"),
  phone: text("phone"),
  isEmailVerified: boolean("is_email_verified").default(false).notNull(),
  role: text("role").default("user").notNull(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const accountsRelations = relations(accounts, ({ one, many }) => ({
  user: one(users, { fields: [accounts.userId], references: [users.id] }),
  refreshTokens: many(refreshTokens),
  emailTokens: many(emailTokens),
}));

export const refreshTokens = pgTable("refresh_tokens", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").notNull().references(() => accounts.id),
  tokenHash: text("token_hash").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const refreshTokensRelations = relations(refreshTokens, ({ one }) => ({
  account: one(accounts, { fields: [refreshTokens.accountId], references: [accounts.id] }),
}));

export const emailTokens = pgTable("email_tokens", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").notNull().references(() => accounts.id),
  token: text("token").notNull().unique(),
  type: text("type").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const emailTokensRelations = relations(emailTokens, ({ one }) => ({
  account: one(accounts, { fields: [emailTokens.accountId], references: [accounts.id] }),
}));

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertGroupScheduleSchema = createInsertSchema(groupSchedule).omit({ id: true });
export const insertBookingSchema = createInsertSchema(bookings).omit({ id: true, createdAt: true });
export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({ id: true, createdAt: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type GroupSchedule = typeof groupSchedule.$inferSelect;
export type InsertGroupSchedule = z.infer<typeof insertGroupScheduleSchema>;
export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Account = typeof accounts.$inferSelect;
export type RefreshToken = typeof refreshTokens.$inferSelect;
export type EmailToken = typeof emailTokens.$inferSelect;
